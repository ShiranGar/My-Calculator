package com.example.firstapp;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.Scriptable;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    TextView resultTV, solutionTV;
    StringBuilder expression;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        resultTV = findViewById(R.id.input);
        solutionTV = findViewById(R.id.output);
        expression = new StringBuilder();

        // Find and set click listeners for all buttons
        int[] buttonIds = {
                R.id.buttonC, R.id.buttonAC, R.id.buttonDivision, R.id.buttonMult,R.id.buttonPercentage,
                R.id.buttonPlus, R.id.buttonMinus, R.id.buttonEqual, R.id.buttonDot,
                R.id.buttonZero, R.id.buttonOne, R.id.buttonTwo, R.id.buttonThree,
                R.id.buttonFour, R.id.buttonFive, R.id.buttonSix, R.id.buttonSeven,
                R.id.buttonEight, R.id.buttonNine
        };

        for (int buttonId : buttonIds) {
            Button button = findViewById(buttonId);
            button.setOnClickListener(this);
        }
    }

    @Override
    public void onClick(View view) {
        Button clickedButton = (Button) view;
        String buttonText = clickedButton.getText().toString();

        switch (buttonText) {
            case "C":
                clearExpression();
                break;
            case "AC":
                clearAll();
                break;
            case "=":
                evaluateExpression();
                break;
            case "%":
                applyPercentage();
                break;
            default:
                appendToExpression(buttonText);
                break;
        }
    }

    private void appendToExpression(String value) {
        expression.append(value);
        resultTV.setText(expression.toString());
    }

    private void clearExpression() {
        if (expression.length() > 0) {
            expression.deleteCharAt(expression.length() - 1);
            resultTV.setText(expression.toString());
        }
    }

    private void clearAll() {
        expression.setLength(0);
        resultTV.setText("");
        solutionTV.setText("");
    }

    private void evaluateExpression() {
        Context rhino = Context.enter();
        rhino.setOptimizationLevel(-1);

        try {
            Scriptable scope = rhino.initStandardObjects();
            Object result = rhino.evaluateString(scope, expression.toString(), "JavaScript", 1, null);

            // Check if the result is Infinity or NaN
            if (result instanceof Double && (((Double) result).isInfinite() || ((Double) result).isNaN())) {
                solutionTV.setText("Error");
            } else {
                // Display result
                solutionTV.setText("= " + Context.toString(result));
            }
        } catch (ArithmeticException e) {
            // Handle division by zero
            solutionTV.setText("Error");
        } catch (Exception e) {
            solutionTV.setText("Error");
        } finally {
            Context.exit();
        }
    }

    private void applyPercentage() {
        if (expression.length() > 0) {
            // Convert the current expression to a double and calculate the percentage
            double value = Double.parseDouble(expression.toString());
            double percentage = value / 100.0;

            // Display the percentage in the resultTV
            resultTV.setText(String.valueOf(percentage));

            // Clear the expression for the next input
            expression.setLength(0);
            expression.append(percentage);
        }
    }
}